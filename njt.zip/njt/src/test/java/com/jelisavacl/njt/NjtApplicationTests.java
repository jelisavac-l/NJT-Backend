package com.jelisavacl.njt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NjtApplicationTests {

	@Test
	void contextLoads() {
	}

}
