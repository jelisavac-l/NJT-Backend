package com.jelisavacl.njt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NjtApplication {

	public static void main(String[] args) {
		SpringApplication.run(NjtApplication.class, args);
	}

}
